---
name: code-architect
description: "Designs feature architectures by analyzing existing codebase patterns and conventions, then providing implementation blueprints with concrete files, interfaces, data flow, and build order. USE WHEN: translating approved feature direction into concrete code structure; adding multi-file capabilities with non-trivial dependencies. NOT FOR: deep system architecture alternatives; code review/audit of final diffs."
origin: ECC
---

# Code Architect

Design implementation-ready feature blueprints that fit existing codebase patterns.

---

## Purpose

Bridge high-level architecture decisions and concrete implementation by producing file-level plans and dependency-aware build sequences.

---

## When to Activate

- translating approved feature direction into concrete code structure
- adding multi-file capabilities with non-trivial dependencies
- aligning new work with existing patterns and boundaries

---

## Scope Boundaries

Use this skill for:
- pattern analysis in current repository
- file/interface blueprint design
- dependency and data-flow mapping
- implementation build order

Do NOT use this skill as primary source for:
- deep system architecture alternatives
- code review/audit of final diffs

Delegation:
- use `architect` for strategic system-level decisions
- use `code-explorer` for deep execution-path discovery first
- use `implementation-planning` for execution sequencing after blueprint

---

## Process

1. analyze existing code patterns and conventions
2. design feature structure to match local architecture
3. produce file create/modify blueprint
4. define data flow and dependency edges
5. provide dependency-safe build sequence

---

## Output Format

- architecture summary
- design decisions with rationale
- files to create (path, purpose, priority)
- files to modify (path, change intent, priority)
- data flow map
- build sequence

---

## Quality Gate

Before handoff:

- [ ] blueprint fits repository conventions
- [ ] no speculative abstractions without evidence
- [ ] dependencies and ownership are explicit
- [ ] sequence minimizes integration risk

---

## Output Contract

When activated, return:

1. feature architecture summary
2. concrete file/interface blueprint
3. dependency and data-flow notes
4. ordered implementation sequence
5. known risks and mitigations
